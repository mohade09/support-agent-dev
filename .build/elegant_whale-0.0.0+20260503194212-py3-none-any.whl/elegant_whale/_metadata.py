from pathlib import Path

app_name = "elegant-whale"
app_entrypoint = "elegant_whale.backend.app:app"
app_slug = "elegant_whale"
api_prefix = "/api"
dist_dir = Path(__file__).parent / "__dist__"